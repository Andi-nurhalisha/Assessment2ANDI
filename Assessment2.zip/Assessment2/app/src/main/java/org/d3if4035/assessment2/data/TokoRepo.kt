package org.d3if4035.assessment2.data

import androidx.lifecycle.LiveData

class TokoRepo(private val tokoDao: TokoDao) {
    val getAllDataToko: LiveData<List<TokoEntity>> = tokoDao.getDataToko()

    suspend fun addToko(tokoEntity: TokoEntity){
        tokoDao.insert(tokoEntity)
    }

    suspend fun deleteToko(tokoEntity: TokoEntity){
        tokoDao.delete(tokoEntity)
    }
}